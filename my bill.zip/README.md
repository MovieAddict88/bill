
ISP Management System


To setup this project:
    1. Import the kp_db.sql to you MySQL server <br>
    2. Edit the config/params.php and config/dbconnection.php file according to you server and path location. <br>
    3. Login the dashboard with the following credintials: <br>
                username : admin <br>
                password : 12345678
